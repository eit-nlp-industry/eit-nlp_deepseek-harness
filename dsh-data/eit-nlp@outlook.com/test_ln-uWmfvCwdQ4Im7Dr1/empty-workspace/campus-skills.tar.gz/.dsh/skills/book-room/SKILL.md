---
name: book-room
description: Use when the user asks to reserve a campus study room, discussion room, or meeting room, and wants candidate rooms filtered by headcount, time slot and location, then added to participants' schedules with email reminders. Card-first, every question is a render_ui form or a display card, no HTML files.
---

# 预约房间（卡片优先）

一次只办一个预约。全程只用 `render_ui`（form / display）和文字，不生成 HTML、不装插件。

## 先看硬约束

卡片表单一轮只能问一个字段，且只有两种意图：`generic_pick_one`（单选）和 `generic_filters`（筛选）。所以：

- 没有下拉框；用单选卡代替，选项文本里带完整字段。
- 每张表单 3–4 个候选，单个选项 ≤ 40 字，`business_data` 保持扁平（字符串或字符串数组），不要嵌套对象数组。
- 表单提交后值会作为下一条用户消息回来，直接读，**不要重复问同一件事**。
- 生成失败时降级：把选项压成 3 条纯字符串重试一次；仍失败就改文字提问，不要卡住。

## 必需信息

| 字段 | 缺失时 |
| --- | --- |
| 日期 | 默认今天，并在确认卡里标注"默认今天" |
| 时段 | 出时段卡：18:00–20:00 / 19:00–21:00 / 20:00–22:00 |
| 人数 | 出人数卡：3 / 4 / 6 / 8 人（含一句"你加几位同学"） |
| 参与者姓名 | 文字提问，或 `ask_user_question` 自由输入；多人时逐条确认 |
| 地点偏好 | 可选，缺省按"离用户当前位置最近"排序 |

## 流程

1. **补齐信息**：按上表逐项补，缺哪个问哪个，一次一张卡。
2. **检索候选**（模拟数据源，假设有"教室空闲表"接口）：过滤容量 ≥ 人数、时段不冲突，按距离排序。
3. **候选卡**（`mode: form`，`intent: generic_pick_one`）：每项含「馆 · 房间号」「容量」「时段」「位置」「状态」。
4. **人数卡**（若第 1 步未定）：选项带备注，例如「4 人：你加两位同学，空间宽松」。
5. **确认卡**（`mode: display`，`answer_presentation: supplement`）：房间、时段、参与人、提醒。
6. **模拟副作用**：把预约写进所有参与人的日程，并发邮件提醒。
   - 在卡片和文字里都标注"模拟"。
   - 真实发送需要 SMTP / 日历 API，或 n8n 的 Gmail、Google Calendar 节点；skill 本身发不出去。

## 副作用（全部为模拟）

- 占座：无真实库存接口，预约号自拟（如 `M-208-1130`）。
- 日程：只写进确认卡；要真日历就导出 `.ics`，由用户导入。
- 邮件：只写进确认卡的"提醒"行；真发要接邮件服务。

## 输出模板

确认卡字段：房间、时段、参与人、预约号（模拟）、提醒事项、模拟说明。

## 不要做

- 不要承诺"已真的占座/已发出邮件"。
- 不要在一轮里连问两个字段。
- 不要在卡片失败后改用 HTML 文件绕过，除非用户明确要求。
