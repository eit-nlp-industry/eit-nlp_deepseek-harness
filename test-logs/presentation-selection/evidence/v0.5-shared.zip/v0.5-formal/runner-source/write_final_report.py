"""Build the benchmark report from audited reviews, retaining per-output scores."""
from pathlib import Path
import json, statistics
P=Path('C:/Users/CJY/.codex/visualizations/2026/11/18/01a1ede2-d2d9-7603-a35c-f4b22a5e8e4a/campus-benchmark/v0.5-formal')
def read(name):return json.loads((P/name).read_text('utf8'))
def write(name,lines):(P/name).write_text(('\n'.join(lines)+'\n').replace('.png)', '.jpg)'), 'utf8')
plan=read('confirmed-plan.json'); agg=read('aggregates.json'); rows=read('results-index.json'); audit=read('final-audit.json')
assert len(rows)==176 and not audit['problems'], 'Finish and audit every planned run before publication'
bycase={x['case_id']:x for x in plan['cases']}
cards={x['id']:x for x in plan['cards']}
categories={x['id']:x for x in plan['categories']}
recommend={
'G01':('优先 A：短文字/回执','单个事实或简短执行回执，动态卡片没有形成稳定收益；明确区分支付成功、结算未知和动作失败。'),
'G02':('默认 A；有切换需求时条件使用 B','Tabs 实际可切换套餐/地点，适合按需浏览；少量内容直接分节。先解决未注册组件和展示被提问阻塞。'),
'G03':('优先 A：静态比较表 + 理由','本轮四项以内比较用 Markdown 已足够；B 可做密集并列卡片，但未验证本地筛选引擎，不能为表格外观增加假交互。'),
'G04':('优先 A：原生提问','少量未知偏好用原生单选/多选/自由回答；多字段集中填写可条件使用 B，但须验自由文本真实回传，推荐预选不算提交。'),
'G05':('优先 A：图片 + 简短确认','重点是先看到正确对象和照片再确认。B 只有在同样满足可见性和状态回传时才值得使用，不能用卡片替代真实证据。'),
'G06':('A 可直接并列；B 可条件用于 Tabs','多视角 Tabs 已验证切换价值，但会增加来回切换；本轮未表现出总分优势。确认前保证所有证据可访问，未知成因和退货资格不补全。'),
'G07':('当前优先 A；B 待提交链路修复','结构化业务表单有编辑价值，当前部署存在值丢失、目标时段缺失和按钮无回传；上线规则须要求字段、附件ID与提交回执逐项一致。'),
'G08':('A/B 均可；已有表单时条件使用 B','两组均能处理冲突与合法替代时段。B 要保留原值、仅列已返回选项，选定后真实提交，不能自动换成推荐值。'),
'G09':('需要直接重排时条件使用 B','SortableSequence 有原生文字无法提供的直接操控价值，但非校园第二次按钮事件名错误导致保存失败。普通顺序说明用 A；接通应用事件后再优先 B。'),
'G10':('当前优先 A：固定图 + 文字路线','静态底图和点位不等于路线已绘制；本轮动态路线有缺线与超时。MapPreview 自定义底图、实时追踪不能推定可用。'),
'G11':('优先 A：文字状态 + 确认事件','多状态更新更需要正确生命周期和去重；当前 B 的重复卡片、未注册时间线和错误百分比影响可信度。只在确有持续可视监控需求并验证状态同步后采用 B。'),
'G12':('只说明用 A；直接编辑可条件用 B','Workflow 节点编辑/回传可用，但条件路径与真正保存要独立审计。存在不在场仍先等待、缺保存按钮/回执；回环文字不证明有可执行回边。')}
lines=['# 组件呈现方式测评报告 v0.5','',
'本轮 176/176 次测评完成：12 类、38 张卡、44 个独立案例，每例 A/B 各两次。A 为 DSH 原生文字/Markdown、图片与提问；B 为当前部署的 json-render 动态组件及文字兜底。结果用于回答“面对不同需求，最终答案用什么方式呈现更合适”，不包含自主选型、跨模型比较或真实业务执行。','',
'在本轮固定模型、材料和部署中，A 的可读性与状态表达更稳定。B 已显示分类切换、直接重排、节点编辑的交互价值，但未形成整体评分优势；未注册组件、技术字段外露、确认早于证据、提交未接通和流程条件错误限制了当前使用。这里评的是整个生成与接入组合，不能据此断言动态组件这种技术本身较差。','',
'详细方法与限制见 [报告方法与边界](报告方法与边界.md)，模型可选能力及未测项见 [能力清单](能力清单_实测更新.md)，全部输入与脚本见 [执行清单](完整测试清单_执行版.md)。','',
'## 评分与汇总','',
'三项均为 0–5 分：回复是否完整阐述事实 F 占 60%，可读性 R 占 25%，状态表达 S 占 15%。总分 = F×12 + R×5 + S×3。生成耗时与 token 仅记录，不计分，不用于决胜。错误对象、核心数值/路径、虚假成功或必须提交却没有提交，单列核心失败，即使总分不低也不推荐。','',
'|方式|次数|F均分|R均分|S均分|加权均分|12类宏平均|最低–最高|核心通过/部分/失败|','|---|---:|---:|---:|---:|---:|---:|---|---|']
for arm in ['A','B']:
    d=agg['arms'][arm]; s=d['pooled']; c=s['status']
    lines.append(f"|{arm}|{s['n']}|{s['F']:.2f}|{s['R']:.2f}|{s['S']:.2f}|{s['mean']:.2f}|{d['macro_category_score']:.2f}|{s['min']}–{s['max']}|{c.get('pass',0)}/{c.get('partial',0)}/{c.get('fail',0)}|")
lines+=['','运行数加权均分按 88 次/臂等权；宏平均先计算各类均分，再对 12 类等权。分数是描述性结果，不作统计显著性或长尾失败率承诺。两臂每例仅重复两次。','',
'|方式|指定呈现完整|呈现部分完成|呈现失败|','|---|---:|---:|---:|']
for arm in ['A','B']:
    ps=agg['arms'][arm]['pooled']['presentation']
    lines.append(f"|{arm}|{ps.get('pass',0)}|{ps.get('partial',0)}|{ps.get('fail',0)}|")
better=[p for p in agg['pairs'] if p['delta_B_minus_A']>0]
same=[p for p in agg['pairs'] if p['delta_B_minus_A']==0]
lines+=['',f"44 个独立案例按两次均分对照：B 较高 {len(better)} 例、持平 {len(same)} 例、A 较高 {44-len(better)-len(same)} 例。B 较高的案例包括 "+'、'.join(f"{p['case_id']}（+{p['delta_B_minus_A']:.2f}）" for p in better)+"。这些差异同时包含模型事实推断与呈现质量，不能归因于组件的独立作用。",'',
'|域|A 次数/均分|B 次数/均分|','|---|---:|---:|']
for dom,label in [('campus_trace_derived','校园'),('non_campus_transfer','非校园')]:
    da=agg['arms']['A']['domains']; db=agg['arms']['B']['domains']
    if dom not in da:
        dom=next(k for k in da if k!='campus_trace_derived')
    x=da[dom];y=db[dom];lines.append(f"|{label}|{x['n']} / {x['mean']:.2f}|{y['n']} / {y['mean']:.2f}|")
lines+=['','校园与非校园按原始样本数展示，不额外设 50:50 权重。每类仅一张非校园卡，用于早期迁移检查，不代表已覆盖所有通用场景。','',
'|方式|两次验收状态相同的案例|两次分数相同的案例|两次分数绝对差均值|','|---|---:|---:|---:|']
for arm,d in agg['repeat'].items():lines.append(f"|{arm}|{d['same_status_pairs']}/{d['case_pairs']}|{d['same_score_pairs']}/{d['case_pairs']}|{d['mean_absolute_score_gap']:.2f}|")
lines+=['','## 按需求类型的结果与选型建议','',
'|大类|A均分|B均分|校园A/B|非校园A/B|当前建议|','|---|---:|---:|---|---|---|']
for gid,cat in categories.items():
    rs=[r for r in rows if r['category_id']==gid]
    def avg(arm,campus):
        a=[r['weighted_score'] for r in rs if r['arm']==arm and r['run_id'].startswith('C' if campus else 'N')]
        return f'{statistics.mean(a):.2f}'
    a=agg['arms']['A']['categories'][gid];b=agg['arms']['B']['categories'][gid]
    lines.append(f"|{gid} {cat['title']}|{a['mean']:.2f}|{b['mean']:.2f}|{avg('A',True)} / {avg('B',True)}|{avg('A',False)} / {avg('B',False)}|{recommend[gid][0]}|")
for gid,cat in categories.items():lines+=['',f"**{gid} {cat['title']}**：{recommend[gid][1]}"]
lines+=['','当前没有足够证据把任何整类标为“无条件优先 json-render”。直接重排和节点编辑可作为有条件的动态交互入口；须先通过真实修改、受支持事件、Host 回传、完整数据和回执的验收。普通短答、少量比较、单图确认默认采用 A。','',
'## 代表性证据','',
'|观察|运行与证据|含义|','|---|---|---|',
'|分类浏览可用|[N02-B-01](runs/N02-B-01/team-selected.png)|实际切换基础版→团队版，详情可见；Tabs 的价值是按需浏览|',
'|排序完整链路成功|[N09-B-01 修改](runs/N09-B-01/reordered.png)、[回传与回执](runs/N09-B-01/session.jsonl)|client/review/report 稳定 ID 与完整条目一致|',
'|同类第二次保存失败|[N09-B-02](runs/N09-B-02/final.dom.txt)、[meta](runs/N09-B-02/render-results.json)|生成 order.apply 而非接通的 route.order.apply；不能用一次成功推定稳定可用|',
'|普通输入框不是业务表单|[N07-B-01](runs/N07-B-01/final.png)、[N07-B-02](runs/N07-B-02/final.png)|联系人能改、图片能切，点击提交却无 Host 回传/回执，均核心失败|',
'|流程编辑与保存完成不同|[N12-B-01 编辑](runs/N12-B-01/edited-3-days.png)、[回传](runs/N12-B-01/user-inputs.json)|3工作日已回传，但模型仅重绘编辑器，缺少模拟 version2 保存回执|',
'|流程条件错误|[C24-A-02](runs/C24-A-02/final.png)、[C24-B-01](runs/C24-B-01/final.png)|老师在/不在判断前无条件等待材料，两臂均按路径错误判失败|',
'|图像时机|[N05-B-01 确认前](runs/N05-B-01/before-confirm-no-image.png)、[确认后](runs/N05-B-01/after-confirm.png)|不能让用户在看不到图片时确认；A 的 C10-A-01 也出现组合时机问题|',
'|MapPreview 只有点位|[N10-B-01](runs/N10-B-01/initial-map.png)|MapPreview 的 SVG 有三个 circle、没有 path/line/polyline；独立 Image 底图仍有固定路线，不代表 MapPreview 画线成功|',
'|超时后诚实兜底|[N10-B-02](runs/N10-B-02/final.png)|两次180秒超时后保留坐标与路线文字，未生成地图；耗时不扣分，缺少要求的呈现仍扣分|','',
'截图是单一时刻视口，完整交互请结合对应的阶段 DOM、user-inputs、render-results 和原始 Session，不以最终截图推断此前所有状态。','',
'## 完整的逐例对照','',
'表内为两次原始总分及均值，括号为最低–最高；Δ=B−A。每次三维评分及具体扣分在下一节。','',
'|案例|任务|A两次 / 均值|B两次 / 均值|Δ|','|---|---|---|---|---:|']
for pair in agg['pairs']:
    cid=pair['case_id'];c=bycase[cid]
    def cell(arm):
        rs=sorted([r for r in rows if r['case_id']==cid and r['arm']==arm],key=lambda r:r['repeat'])
        return '、'.join(str(r['weighted_score']) for r in rs)+f" / {pair[arm]['mean']:.2f} ({pair[arm]['min']}–{pair[arm]['max']})"
    lines.append(f"|{cid}|{c['input'].replace('|','／')}|{cell('A')}|{cell('B')}|{pair['delta_B_minus_A']:+.2f}|")
detail=['## 全部 176 次输出的三维评分','',
'验收 pass/partial/fail 与呈现状态分列；pass 不等于满分。F=回复是否完整阐述事实，R=可读性，S=状态表达。','',
'|运行|核心验收|呈现|F|R|S|总分|扣分与证据|','|---|---|---|---:|---:|---:|---:|---|']
for r in sorted(rows,key=lambda r:r['run_id']):
    rid=r['run_id']; reason=r['reason'].replace('|','／').replace('\n',' ')
    detail.append(f"|[{rid}](runs/{rid}/final.png)|{r['status']}|{r.get('presentation','未记')}|{r['factual_completeness']}|{r['readability']}|{r['state']}|{r['weighted_score']}|{reason} [原始日志](runs/{rid}/session.jsonl)|")
lines+=['']+detail+['','## 验证、边界与日志','',
f"实际首条用户输入与冻结输入匹配；{audit['unique_sessions']} 个独立 Session；全部预设、DSH 模型配置和工具 schema 哈希一致。{audit['environment_files_checked']} 项冻结文件检查中，唯一差异为已禁用的旧 v1 replay.js；活动 v2、渲染适配器/构建、输入及初始材料均保持一致。详见 [审计结果](final-audit.json)。",'',
'4 个运行在脚本最后仍等待原生问题回答，已显式记为 awaiting_user_after_scripted_final_event，不编造后续输入。执行中曾四页面流水并行、跨日及连接中断，最后 B 较集中；两臂排序/流程题得到冻结接入规范提示，因此结论也不代表完全无提示生成。','',
'18 次准备/环境启动另行排除归档；真实质量失败保留在主表。两项评分复核保留修改前证据。C24 的草稿材料没有明确提供前题确认门与等待上限，按本例实际材料评分。详见 [方法与边界](报告方法与边界.md)、[执行台账](progress.md)、[复核记录](score-adjudications.jsonl)。','',
'生成时间观察为 Session 中模型请求区间之和，render_ms 为渲染工具调用区间之和；active_ms 仅是二者相加，不是端到端墙钟或首次可见延迟，不能排除调度/并行因素。渲染服务内部模型与 token 未观测；原生用户等待也不计为生成速度。各次原始指标保存在 metrics.json 与 [汇总 CSV](results-index.csv)。','',
'数据与可复算结果：[逐次评分 JSON](scores.json)、[完整索引](results-index.json)、[聚合统计](aggregates.json)、[材料/文件哈希](artifact-manifest.json)。每个 runs/运行ID/ 中含冻结输入、阶段截图/DOM、实际用户消息、tool/result.meta、模拟环境事件、原始压缩/解压 Session、指标和 review.json。','',
'本轮未发布 Skill。可将通过验证的规则整理为后续 Skill 草稿：先区分展示/收集/修改/控制，少量信息默认原生；需要直接操作时选择已接通动态组件；证据必须先于确认；提交后检查真实回传与回执；失败保留文字并明确未完成。对于图表、实时地图、移动端、上传、导出与分享，仅记录未验证，不写成已支持或不支持。']
write('组件呈现方式测评报告_v0.5.md',lines)
write('逐次评分明细_176次.md',['# 逐次评分明细 v0.5','']+detail)
check=['# 完整测试清单：已执行版 v0.5','',
'用户确认后按冻结 protocol_revision=0.5.1 执行，44 个独立案例×2种呈现×2次=176次。confirmed-plan.json 中 awaiting 文案为准备时历史状态，不代表本次未获确认；执行状态以本文件、run.json 和 scores.json 为准。','',
'|大类|校园案例|非校园案例|','|---|---|---|']
for gid,c in categories.items():
    cc=[x['case_id'] for x in plan['cases'] if x['category_id']==gid]
    check.append(f"|{gid} {c['title']}|{', '.join(x for x in cc if x.startswith('C'))}|{', '.join(x for x in cc if x.startswith('N'))}|")
for case in plan['cases']:
    card=cards[case['card_id']];cid=case['case_id']
    check+=['',f"## {cid} {card['title']}",'',f"输入：{case['input']}",'',f"固定材料：{card['fixed_materials']}",'',f"A：{card['A']}",'',f"B：{card['B']}",'',f"动作脚本：{case['actions']}",'',f"验收：{card['acceptance']}",'',f"执行：{cid}-A-01、A-02、B-01、B-02 均已运行；各次实际注入材料见 runs/对应运行/initial-visible.json，后续释放事件见 environment-inputs.json。"]
write('完整测试清单_执行版.md',check)
print('reports written; per-run table:',len(rows))
