import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';import {join} from 'node:path';
import {apply} from './index.js';
test('the actual registered tool reads separate fixtures for four different Agents',async()=>{
 const root=await mkdtemp(join(tmpdir(),'dsh-bench-isolation-'));const disposers=[];let tool;
 const ctx={on:()=>()=>{},effect(fn){const dispose=fn();if(typeof dispose==='function')disposers.push(dispose)},tools:{register(value){tool=value;return ()=>{}}}};
 try{
  apply(ctx,{root,pollMs:10000});
  for(let i=0;i<4;i++){
   const rid='CASE-'+i;await mkdir(join(root,'runs',rid),{recursive:true});
   await writeFile(join(root,'runs',rid,'operator.json'),JSON.stringify({visible:{marker:i},events:[]}));
   const result=await tool.execute({action:'initialize',run_id:rid},{agent:{id:'session-'+i,followup(){throw Error('unexpected event')}}});
   assert.equal(result.data.marker,i);
   const binding=JSON.parse(await readFile(join(root,'runs',rid,'binding.json'),'utf8'));assert.equal(binding.session_id,'session-'+i);
  }
  const again=await tool.execute({action:'read',run_id:'CASE-0'},{agent:{id:'session-0'}});assert.equal(again.data.marker,0);
 }finally{for(const dispose of disposers.reverse())await dispose();assert.ok(root.startsWith(join(tmpdir(),'dsh-bench-isolation-')));await rm(root,{recursive:true,force:true})}
});
