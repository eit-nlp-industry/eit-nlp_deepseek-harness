/** Build non-user, deduplicated fixture notifications for one benchmark session. */
export function pendingEvents(events, delivered, stopped) {
  if (stopped) return [];
  const seen = new Set(delivered);
  const out = [];
  for (const event of events) {
    if (!event || typeof event.id !== 'string' || seen.has(event.id)) continue;
    seen.add(event.id);
    out.push({role:'user',id:`benchmark-event-${event.id}`,source:{kind:'benchmark-event',eventId:event.id,simulated:true},content:[{type:'text',text:`固定模拟环境事件（不是用户新指令）：\n${JSON.stringify(event)}`} ]});
  }
  return out;
}
/** Bind independent Agent instances without sharing run state. */
export function bindSession(bindings, agent, runId) {
 const prior=bindings.get(agent.id);
 if(prior && prior.runId!==runId)throw Error('This session is bound to another benchmark run');
 if(prior)return prior;
 const entry={agent,runId,delivered:new Set(),closed:false};bindings.set(agent.id,entry);return entry;
}
