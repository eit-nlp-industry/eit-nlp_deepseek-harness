/** Session-isolated fixed replay; reads and writes only the benchmark artifact root. */
import {readFile,writeFile,appendFile} from 'node:fs/promises';
import {join,isAbsolute} from 'node:path';
import {pendingEvents,bindSession} from './replay.js';
export const name='benchmark-replay-v2';
export const inject=['tools'];
/** Register one fixture tool with explicit per-Session state and a disposable poller. */
export function apply(ctx,config){
 if(!config || !isAbsolute(config.root))throw Error('Benchmark fixture root must be absolute');
 const bindings=new Map();let alive=true,pending=Promise.resolve();
 const valid=id=>typeof id==='string'&&/^[A-Za-z0-9-]{3,70}$/.test(id);
 const read=async id=>JSON.parse(await readFile(join(config.root,'runs',id,'operator.json'),'utf8'));
 ctx.on('agent/disposed',({agent})=>{bindings.delete(agent.id)});
 ctx.effect(()=>ctx.tools.register({
  name:'benchmark_fixture',description:'Read fixed mock business state. First initialize with the exact run_id from the benchmark prompt; read returns only currently released facts. submit records actual user-confirmed draft values and returns a staged mock receipt. Never submit before user confirmation. No real business actions, external network or unreleased future events.',
  parameters:{type:'object',properties:{run_id:{type:'string'},action:{type:'string',enum:['initialize','read','submit']},values:{type:'object',additionalProperties:true}},required:['run_id','action']},
  output:{schema:{type:'object',properties:{ok:{type:'boolean'},data:{type:'object',additionalProperties:true},error:{type:'string'}},required:['ok'],additionalProperties:false},render:(_args,value)=>[{type:'text',text:JSON.stringify(value)}]},isConcurrencySafe:()=>false,
  async execute(args,exec){
   if(!valid(args.run_id)||!exec.agent)throw Error('Invalid benchmark execution');
   const prior=bindings.get(exec.agent.id);
   if(prior&&prior.runId!==args.run_id)throw Error('This session is bound to another benchmark run');
   const spec=await read(args.run_id);
   if(args.action==='initialize'){
    const entry=bindSession(bindings,exec.agent,args.run_id);
    await writeFile(join(config.root,'runs',entry.runId,'binding.json'),JSON.stringify({run_id:entry.runId,session_id:entry.agent.id,bound_at:new Date().toISOString()},null,2));
   }
   const entry=bindings.get(exec.agent.id);
   if(!entry)return {ok:false,error:'Initialize this benchmark run first'};
   if(args.action==='submit'){
    await appendFile(join(config.root,'runs',entry.runId,'mock-submissions.jsonl'),JSON.stringify({at:new Date().toISOString(),session_id:entry.agent.id,values:args.values})+'\n');
    if(!spec.submission)return {ok:false,error:'No mock submission response has been released'};
    for(const [k,v] of Object.entries(spec.submission.expected??{}))if(JSON.stringify(args.values?.[k])!==JSON.stringify(v))return {ok:false,error:`Submitted value differs for ${k}`};
    return {ok:true,data:{...spec.submission.response,submitted:args.values??{}}};
   }
   return {ok:true,data:spec.visible??{}};
  }
 }));
 ctx.effect(()=>{
  const poll=async()=>{
   for(const entry of bindings.values()){
    if(!alive)return;if(entry.closed)continue;
    const spec=await read(entry.runId);if(!alive)return;
    if(spec.monitoringEnded===true){entry.closed=true;continue;}
    for(const msg of pendingEvents(spec.events??[],entry.delivered,false)){
     if(!alive)return;entry.agent.followup(msg);entry.delivered.add(msg.source.eventId);
     await appendFile(join(config.root,'runs',entry.runId,'event-delivery.jsonl'),JSON.stringify({at:new Date().toISOString(),session_id:entry.agent.id,eventId:msg.source.eventId})+'\n');
    }
   }
  };
  let busy=false;const timer=setInterval(()=>{
   if(busy||!alive)return;busy=true;
   pending=poll().catch(async error=>{alive=false;await appendFile(join(config.root,'fixture-errors-v2.jsonl'),JSON.stringify({error:String(error),at:new Date().toISOString()})+'\n')}).finally(()=>{busy=false});
  },config.pollMs??800);timer.unref();
  return async()=>{alive=false;clearInterval(timer);await pending;bindings.clear()};
 });
}
