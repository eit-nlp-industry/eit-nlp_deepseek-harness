# Benchmark replay fixtures

Agent-scoped mock state and environment-event replay for the confirmed component benchmark. No external business systems, credentials, or network listener. Only reads the configured artifact root and writes this run's binding/submission/event evidence. Effects stop on preset disposal.
