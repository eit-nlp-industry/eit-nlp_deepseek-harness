import test from 'node:test';
import assert from 'node:assert/strict';
import { pendingEvents } from './replay.js';
test('a new environment event is delivered once and has no ordinary user source',()=>{
 const e={id:'e1',kind:'observation',data:{door:'open'}};
 const first=pendingEvents([e],new Set(),false);
 assert.equal(first.length,1);
 assert.equal(first[0].source.kind,'benchmark-event');
 assert.equal(pendingEvents([e],new Set(['e1']),false).length,0);
});
test('ended monitoring suppresses late events',()=>{
 assert.equal(pendingEvents([{id:'late',data:{failed:true}}],new Set(),true).length,0);
});
test('repeated event ids in one poll do not emit duplicate notifications',()=>{
 assert.equal(pendingEvents([{id:'a',data:{}},{id:'a',data:{}}],new Set(),false).length,1);
});
test('four independent sessions bind to four runs without sharing delivered ids',async()=>{
 const {bindSession}=await import('./replay.js');const bindings=new Map();
 for(let i=0;i<4;i++)bindSession(bindings,{id:'session-'+i},'run-'+i);
 assert.equal(bindings.size,4);bindings.get('session-0').delivered.add('event');
 assert.equal(bindings.get('session-1').delivered.size,0);
});
test('rebinding one session to another run is rejected',async()=>{
 const {bindSession}=await import('./replay.js');const b=new Map();bindSession(b,{id:'same'},'run1');
 assert.throws(()=>bindSession(b,{id:'same'},'run2'),/another benchmark run/);
});
