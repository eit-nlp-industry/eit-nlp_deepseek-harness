"""Audit fixed benchmark artifacts and derive transparent descriptive statistics."""
from pathlib import Path
from collections import Counter, defaultdict
import json, hashlib, statistics, csv

P = Path('C:/Users/CJY/.codex/visualizations/2026/11/18/01a1ede2-d2d9-7603-a35c-f4b22a5e8e4a/campus-benchmark/v0.5-formal')
def read(p):
    return json.loads(p.read_text('utf8'))
def dump(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', 'utf8')
frozen=read(P/'frozen-run-inputs.json')
scores={r['run_id']:r for r in read(P/'scores.json')}
rows=[]; problems=[]; sessions=[]; terminals=[]; request_models=Counter(); request_schemas=Counter()
for f in frozen:
    rid=f['run_id']; d=P/'runs'/rid
    if rid not in scores:
        problems.append(rid+': missing score'); continue
    run=read(d/'run.json'); m=read(d/'metrics.json'); s=scores[rid]
    if run['status'] != s['status']: problems.append(rid+': score/status mismatch')
    if any(not isinstance(s[k],int) or not 0<=s[k]<=5 for k in ['factual_completeness','readability','state']): problems.append(rid+': invalid component score')
    if s['weighted_score'] != s['factual_completeness']*12+s['readability']*5+s['state']*3: problems.append(rid+': wrong weighted score')
    if (f['arm']=='A' and m['render_calls']!=0) or (f['arm']=='B' and m['render_calls']<1): problems.append(rid+': assigned arm not followed')
    actual=read(d/'user-inputs.json')
    if not actual or actual[0]['text'] != f['prompt']:
        problems.append(rid+': actual first message mismatch')
    if (d/'input.txt').read_text('utf8').removesuffix('\n') != f['prompt']:
        problems.append(rid+': input file mismatch')
    if hashlib.sha256(f['prompt'].encode()).hexdigest() != f['prompt_sha256']:
        problems.append(rid+': frozen prompt hash mismatch')
    if run['status'] not in ['pass','partial','fail']:
        problems.append(rid+': nonterminal review')
    for name in ['final.png','final.dom.txt','session.jsonl','render-results.json','source-session.json']:
        if not (d/name).exists(): problems.append(rid+': missing '+name)
    session_raw=(d/'session.jsonl').read_bytes()
    fixture_calls={}; fixture_results=[]
    for event in (json.loads(line) for line in session_raw.decode('utf8').splitlines()):
        ev=event.get('data') or {}
        if event['type']=='tool/call' and ev.get('name')=='benchmark_fixture':
            fixture_calls[ev['callId']]={'seq':event['seq'],'arguments':json.loads(ev['arguments'])}
        if event['type']=='tool/result':
            msg=ev.get('message') or {};call_id=msg.get('toolCallId') or (msg.get('source') or {}).get('callId')
            if call_id in fixture_calls:fixture_results.append({'call':fixture_calls[call_id],'result_seq':event['seq'],'meta':ev.get('meta'),'message':msg})
        if event['type']=='request/header':
            header=event['data']['header']; config=header.get('config') or {}
            model={k:config[k] for k in ['provider','model','reasoningEffort'] if k in config}
            request_models[json.dumps(model,sort_keys=True)]+=1
            request_schemas[hashlib.sha256(json.dumps(header.get('tools'),ensure_ascii=False,sort_keys=True).encode()).hexdigest()]+=1
    dump(d/'fixture-results.json',fixture_results)
    if hashlib.sha256(session_raw).hexdigest()!=read(d/'source-session.json')['sha256']:
        problems.append(rid+': session hash mismatch')
    if m['turns_started'] != m['turns_ended']:
        terminals.append({'run_id':rid,'started':m['turns_started'],'ended':m['turns_ended'],'declared_terminal':run.get('terminal_state')})
    sessions.append(m['session_id'])
    rows.append({k:f[k] for k in ['run_id','case_id','card_id','category_id','scenario_domain','arm','repeat']} | s | {'session_id':m['session_id'],'model_ms':m['model_ms'],'render_ms':m['render_ms'],'active_ms':m['active_ms'],'tokens':m['usage'].get('totalTokens'), 'render_calls':m['render_calls'],'question_calls':m['question_calls'],'human_messages':len(actual)})
if len(sessions)!=len(set(sessions)): problems.append('duplicate primary Session')
initial_groups=defaultdict(set)
for row in rows:
    initial_groups[row['case_id']].add(hashlib.sha256((P/'runs'/row['run_id']/'initial-visible.json').read_bytes()).hexdigest())
for cid,values in initial_groups.items():
    if len(values)!=1:problems.append(cid+': initial material differs across arms/repeats')
metrics=[read(P/'runs'/r['run_id']/'metrics.json') for r in rows]
audit={'planned':len(frozen),'scored':len(rows),'unique_sessions':len(set(sessions)),'problems':problems,'nonclosed_turns':terminals,'presets':dict(Counter(m['selected_preset'] for m in metrics)),'models':dict(Counter(json.dumps(m['model'],sort_keys=True) for m in metrics)),'tool_schema_hashes':dict(Counter(m['tools_schema_sha256'] for m in metrics))}
audit['all_request_models']=dict(request_models);audit['all_request_tool_schemas']=dict(request_schemas)
audit['initial_material_groups']=len(initial_groups)
audit['tool_names']=dict(Counter(name for m in metrics for name in m['tool_calls']))
incidents=[]
for root in ['environment-incidents','protocol-incidents']:
    for path in sorted((P/root).rglob('run.json')):
        incident=read(path)
        incidents.append({'path':path.relative_to(P).as_posix(),'run_id':incident.get('run_id'),'status':incident.get('status')})
audit['excluded_started_count']=len(incidents);audit['excluded_starts']=incidents
changes=[]; missing=[]
for path, expected in read(P/'frozen-environment-sha256.json').items():
    p=Path(path)
    if not p.exists(): missing.append(path)
    elif hashlib.sha256(p.read_bytes()).hexdigest()!=expected: changes.append(path)
audit['environment_files_checked']=len(read(P/'frozen-environment-sha256.json'))
audit['environment_changed']=changes; audit['environment_missing']=missing
dump(P/'final-audit.json',audit)
dump(P/'results-index.json',rows)
if rows:
    with (P/'results-index.csv').open('w',encoding='utf-8-sig',newline='') as out:
        w=csv.DictWriter(out,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
def stats(rs):
    vals=[r['weighted_score'] for r in rs]
    return {'n':len(rs),'mean':round(statistics.mean(vals),2),'min':min(vals),'max':max(vals),'F':round(statistics.mean(r['factual_completeness'] for r in rs),2),'R':round(statistics.mean(r['readability'] for r in rs),2),'S':round(statistics.mean(r['state'] for r in rs),2),'status':dict(Counter(r['status'] for r in rs)),'presentation':dict(Counter(r.get('presentation','unrecorded') for r in rs)),'model_ms_median':statistics.median(r['model_ms'] for r in rs),'render_ms_median':statistics.median(r['render_ms'] for r in rs)}
aggs={}
for arm in ['A','B']:
    a=[r for r in rows if r['arm']==arm]
    if not a: continue
    bycat={g:stats([r for r in a if r['category_id']==g]) for g in sorted(set(r['category_id'] for r in a))}
    aggs[arm]={'pooled':stats(a),'macro_category_score':round(statistics.mean(v['mean'] for v in bycat.values()),2),'categories':bycat,'domains':{dom:stats([r for r in a if r['scenario_domain']==dom]) for dom in sorted(set(r['scenario_domain'] for r in a))}}
pairs=[]
for case in sorted(set(r['case_id'] for r in rows)):
    arms={a:[r for r in rows if r['case_id']==case and r['arm']==a] for a in ['A','B']}
    pairs.append({'case_id':case,**{a:stats(rs) for a,rs in arms.items() if rs},'delta_B_minus_A':round(statistics.mean(r['weighted_score'] for r in arms['B'])-statistics.mean(r['weighted_score'] for r in arms['A']),2) if all(arms.values()) else None})
repeat={}
for arm in ['A','B']:
    groups=defaultdict(list)
    for r in rows:
        if r['arm']==arm:groups[r['case_id']].append(r)
    both=[rs for rs in groups.values() if len(rs)==2]
    if both:repeat[arm]={'case_pairs':len(both),'same_status_pairs':sum(rs[0]['status']==rs[1]['status'] for rs in both),'same_score_pairs':sum(rs[0]['weighted_score']==rs[1]['weighted_score'] for rs in both),'mean_absolute_score_gap':round(statistics.mean(abs(rs[0]['weighted_score']-rs[1]['weighted_score']) for rs in both),2)}
dump(P/'aggregates.json',{'arms':aggs,'pairs':pairs,'repeat':repeat})
print(json.dumps(audit,ensure_ascii=False))
