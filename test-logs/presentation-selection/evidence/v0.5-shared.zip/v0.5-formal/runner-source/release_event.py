"""Release one predefined mock event; never replace it with a human user message."""
from pathlib import Path
import argparse,json,os,datetime
P=Path(r'C:/Users/CJY/.codex/visualizations/2026/11/18/01a1ede2-d2d9-7603-a35c-f4b22a5e8e4a/campus-benchmark/v0.5-formal')
a=argparse.ArgumentParser();a.add_argument('run_id');a.add_argument('stage');args=a.parse_args()
runs=json.loads((P/'frozen-run-inputs.json').read_text('utf8'));r=next(x for x in runs if x['run_id']==args.run_id);d=P/'runs'/r['run_id'];f=d/'operator.json';op=json.loads(f.read_text('utf8'))
if args.stage=='accept_submit':op['submission']={'response':{'status':'draft_received','simulated':True,'real_operation':False}}
else:
 plans=json.loads((P/'fixtures/event-templates.private.json').read_text('utf8'));key=r['case_id'] if r['case_id'] in plans else r['card_id'];data=plans[key][args.stage]
 delivery_id=r['run_id']+'-'+args.stage
 op['visible'].update(data);op['events'].append(dict(id=delivery_id,kind='fixed_business_event',data=data))
tmp=f.with_suffix('.tmp');tmp.write_text(json.dumps(op,ensure_ascii=False,indent=2)+'\n',encoding='utf8');os.replace(tmp,f)
with(d/'operator-actions.jsonl').open('a',encoding='utf8') as log:log.write(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stage=args.stage,release='mock_tool_response' if args.stage=='accept_submit' else 'environment_event'),ensure_ascii=False)+'\n')
print(args.run_id+' released '+args.stage)
