from pathlib import Path
import json, os, datetime
P=Path('C:/Users/CJY/.codex/visualizations/2026/11/18/01a1ede2-d2d9-7603-a35c-f4b22a5e8e4a/campus-benchmark/v0.5-formal')
count=0
for f in (P/'runs').glob('*/run.json'):
 r=json.loads(f.read_text('utf8'))
 if r['status'] not in ('pass','partial','fail'):continue
 opfile=f.parent/'operator.json';op=json.loads(opfile.read_text('utf8'))
 if op.get('monitoringEnded'):continue
 op['monitoringEnded']=True
 tmp=f.parent/'operator.driver-stop.tmp';tmp.write_text(json.dumps(op,ensure_ascii=False,indent=2)+'\n','utf8');os.replace(tmp,opfile)
 with (f.parent/'operator-actions.jsonl').open('a',encoding='utf8') as log:log.write(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'action':'stop_fixture_driver_after_final_capture','business_event':False})+'\n')
 count+=1
print(json.dumps({'stopped_completed_drivers':count}))
