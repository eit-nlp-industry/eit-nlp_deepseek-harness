from pathlib import Path
import json
P=Path('C:/Users/CJY/.codex/visualizations/2026/11/18/01a1ede2-d2d9-7603-a35c-f4b22a5e8e4a/campus-benchmark/v0.5-formal')
rows=[]
for f in sorted((P/'runs').glob('*/review.json')):
 d=f.parent;r=json.loads(f.read_text('utf8'));run=json.loads((d/'run.json').read_text('utf8'))
 if run['status'] not in ['pass','partial','fail']:continue
 score=r['factual_completeness']*12+r['readability']*5+r['state']*3
 rows.append({'run_id':d.name,'status':run['status'],**r,'weighted_score':score})
(P/'scores.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n','utf8')
lines=['# 组件呈现测评 v0.5：执行中报告','',f'已评分 {len(rows)}/176 次，尚未形成全量选型结论。完整范围为 44 个独立案例、两种呈现方式、每种两次。','','A：文字/Markdown、原生图片与原生提问。B：json-render 动态组件及文字兜底。固定模型与材料；不测自主选型和不同模型。','','评分：回复是否完整阐述事实 60%，可读性 25%，状态表达 15%。每项 0–5 分，总分 = 事实×12 + 可读性×5 + 状态×3。耗时和 token 仅记录，不计分。','','状态 pass 表示核心验收通过，不表示各项满分；partial 表示部分任务或呈现不完整；fail 表示固定任务无法完成。具体扣分见逐次记录。','','|运行|验收|事实|可读性|状态|总分|证据与扣分|','|---|---|---:|---:|---:|---:|---|']
for r in rows:
 rid=r['run_id'];reason=r['reason'].replace('|','／').replace('\n',' ')
 lines.append(f"|[{rid}](runs/{rid}/final.png)|{r['status']}|{r['factual_completeness']}|{r['readability']}|{r['state']}|{r['weighted_score']}|{reason} [日志](runs/{rid}/session.jsonl)|")
lines+=['','测试准备中排除的启动保存在 environment-incidents 和 protocol-incidents 中。排除原因、材料修订和执行规则见 [执行台账](progress.md)。有效质量失败保留在主表，不重试替换。','','本报告随执行更新；未运行项目不会补写或推断分数。']
(P/'执行中报告.md').write_text('\n'.join(lines)+'\n','utf8')
print(json.dumps({'scored':len(rows),'planned':176}))
