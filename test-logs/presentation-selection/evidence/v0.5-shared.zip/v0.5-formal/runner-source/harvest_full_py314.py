import sys,types,runpy
from compression import zstd
m=types.ModuleType('zstandard')
class D:
 def stream_reader(self,s):return zstd.open(s,'rb')
m.ZstdDecompressor=D
sys.modules['zstandard']=m
runpy.run_path('.artifacts/component-benchmark-preset/harvest_full.py',run_name='__main__')
