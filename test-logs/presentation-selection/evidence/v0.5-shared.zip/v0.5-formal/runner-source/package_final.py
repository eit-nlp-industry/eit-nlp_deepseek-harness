"""Validate local report links, hash every artifact, and make a self-contained archive."""
from pathlib import Path
import json,hashlib,zipfile,re,shutil,datetime
P=Path('C:/Users/CJY/.codex/visualizations/2026/11/18/01a1ede2-d2d9-7603-a35c-f4b22a5e8e4a/campus-benchmark/v0.5-formal')
S=Path('D:/work/project/eit-nlp_deepseek-harness/.artifacts/component-benchmark-preset')
for name in ['audit_final.py','harvest_full.py','harvest_full_py314.py','release_event.py','stop_completed_drivers.py','update_progress_report.py','write_final_report.py','package_final.py']:
    shutil.copy2(S/name,P/'runner-source'/name)
plugin=Path('D:/work/project/eit-nlp_deepseek-harness/.artifacts/benchmark-replay-plugin-v2')
dest=P/'runner-source/replay-plugin-v2';dest.mkdir(exist_ok=True)
for f in plugin.iterdir():
    if f.is_file():shutil.copy2(f,dest/f.name)
aliases=[]
for f in P.rglob('*.png'):
    if f.read_bytes()[:3]==b'\xff\xd8\xff':
        target=f.with_suffix('.jpg');shutil.copy2(f,target)
        aliases.append({'original':f.relative_to(P).as_posix(),'jpeg':target.relative_to(P).as_posix()})
(P/'screenshot-file-types.json').write_text(json.dumps({'note':'Historical screenshot names use .png but bytes are JPEG; .jpg aliases preserve the exact bytes. MOCK PNG resources remain PNG.','aliases':aliases},ensure_ascii=False,indent=2)+'\n','utf8')
files=[f for f in sorted(P.rglob('*')) if f.is_file() and f.name!='artifact-manifest.json']
entries=[{'path':f.relative_to(P).as_posix(),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]
(P/'artifact-manifest.json').write_text(json.dumps({'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':entries,'note':'Manifest excludes itself; all other files in v0.5-formal are listed.'},ensure_ascii=False,indent=2)+'\n','utf8')
missing=[]
reports=['组件呈现方式测评报告_v0.5.md','逐次评分明细_176次.md','完整测试清单_执行版.md','能力清单_实测更新.md','报告方法与边界.md','日志阅读说明.md']
for name in reports:
    text=(P/name).read_text('utf8')
    for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
        if '://' in link or link.startswith('#'):continue
        path=link.split('#')[0]
        if not (P/path).exists():missing.append({'document':name,'link':link})
assert not missing,missing
scores=json.loads((P/'scores.json').read_text('utf8'));audit=json.loads((P/'final-audit.json').read_text('utf8'))
assert len(scores)==176 and audit['unique_sessions']==176 and not audit['problems']
assert audit['excluded_started_count']==18
assert len(audit['all_request_models'])==1 and len(audit['all_request_tool_schemas'])==1
for t in audit['nonclosed_turns']:assert t['declared_terminal']=='awaiting_user_after_scripted_final_event'
out=P.parent/'组件呈现测评_v0.5_176次_完整报告与日志.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in sorted(P.rglob('*')):
        if f.is_file():z.write(f,'v0.5-formal/'+f.relative_to(P).as_posix())
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    count=len(z.infolist())
summary={'archive':str(out),'files':count,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'primary_runs':176,'unique_sessions':176,'excluded_starts':18,'reports_checked':len(reports),'broken_report_links':0}
(P.parent/'v0.5-final-delivery.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n','utf8')
print(json.dumps(summary,ensure_ascii=False))
