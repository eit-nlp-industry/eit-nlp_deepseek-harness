# Execution ledger — benchmark v0.5, confirmed 44 cases / 176 runs

- User confirmed scope and 2 repeats per arm. No autonomous selection.
- Scoring: factual completeness 60%, readability 25%, state 15%; timing unscored.
- Prepared 28 deterministic MOCK media assets; original media catalog rows preserved.
- Formal runs: 0/176. Preflight is in progress.
- Ruling: Keep operator future answers and future event outcomes out of initial model facts; admit them only at their scripted step.
- Ruling: Workflow can use existing adapter intent=rich_content with components omitted if its enum lacks Workflow; preflight must prove actual Workflow payload and editor, not static substitutes.

- Installed and enabled @local/dsh-benchmark-replay v0.1.0 through DSH UI, adding only Component benchmark full; existing presets retained. No restart needed.
- PRE-EVENT-A-01 actual session: session-71c10c28-4d90-45d9-ad70-303edf0ed7c0. Source kind benchmark-event verified in raw Session.
- Workflow initial complex generation had JSON but no visible editor; minimal valid layout rendered, actual node description changed 1 to 2 minutes and save produced a new Workflow with 2 minutes.
- Sorting first generated a Button as a child of the leaf SortableSequence, so it was not visible. Valid sibling-Stack layout is under preflight.
- Ruling: For maps, the current catalog has no custom background parameter. Show the same Image base alongside MapPreview normalized coordinates instead of inventing a background prop. Record this representation limitation.
- Ruling: Use the component's documented keyboard reorder on its real handle where browser-native pointer dragging is unavailable; record the actual input method and application event.
- Prepared all 176 run directories, separate initial-visible facts and private operator controls; future user replies/outcomes excluded from initial model input.

- Fixture defect discovered on first four starts: the preset plugin instance is reused across Agents, so v0.1 shared its single binding. All four starts excluded as fixture/environment incidents; their raw Sessions and screenshots are preserved under environment-incidents/singleton-binding-v1. No valid formal samples yet.
- Corrected fixture v0.2 uses Agent.id-keyed bindings and independent delivered-event sets. A four-Agent registered-tool isolation check and five focused behavior checks pass. Installing a separately named v2 bundle avoids reusing cached Host module code.

- Restarted 3080 via supported dsh Web profile (same media patch plus required in-page picker overlay), exec session 28344. Authentication restored without exposing/storing launch token in final artifacts.
- Four actual v2 Sessions now verified independent; same event id delivered only to its two designated Sessions, zero leakage to the other two. Refroze environment with component-benchmark-full-v2 / fixture 0.2.0.

- Protocol revision 0.5.1: a generic B instruction saying to require Workflow was interpreted literally by C01-B-02, generating an extra workflow. Archived all four same-batch A/B outputs under protocol-incidents/common-workflow-hint-v1; do not use them as primary comparison scores. Retain generated quality defects in the incident appendix. Removed this guidance from non-workflow cases, retaining it only in C23/C24/N12. Same 176-case run matrix, facts, weights and operator actions. No valid primary samples yet; restart the C01 batch under revision 0.5.1.

- Browser helper retained its earlier fullRuns closure after the prompt file revision. Raw-prompt audit caught old B instructions still being sent. Archived the four starts under protocol-incidents/browser-cached-input-v1. Use direct per-call file reads in the browser start block, never the cached fullRuns array; verify actual Session first user text equals frozen input before counting a sample.

- 8 valid primary runs complete: C01 (4) and C02-a (4); C02-b (4) running. Verified all collected actual inputs equal frozen revision 0.5.1 and effective preset is full-v2. C01 dynamic tabs/images work across all three tabs; generated List elements render as unregistered placeholders, preserved as genuine partial presentation failure. Core facts recoverable from prose. C01 provisional F/R/S: A 5/5/5, B 5/3/3.
- Browser handles: selected browser2, fullTabs[0..3] IDs 5/6/7/8; dshTab=recoveredTab (new authenticated tab). Use beginVerified (reads frozen file inside each invocation), endVerified, captureFullAt, replyFullAt. Do NOT use startFullAt/fullRuns for starts; their old closure cached pre-revision input.

- 16 valid primary runs complete through C03. Four C04-a starts excluded: public material mixed C04-b/c fields. Archived raw Sessions and initial views before splitting C04 public facts by subcase (C04-scope-v2); frozen prompt text and scoring unchanged. C04-a will restart.

- 48/176 valid scored runs complete through C08; C09 four sessions awaiting environment events. Runtime input audit: all actual initial prompts match frozen inputs; unique Sessions; one model/preset/tool-schema hash. C04 corrected material scope frozen separately. Genuine dynamic quality issues retained: missing List registry, dropped free-text field in C04-b-B-01, C05-B-02 cannot accept scripted slot, C08 image appears only after confirmation. Independent sessions are pipelined across cases to use idle tabs; run IDs/materials/repeats unchanged, actual times retained.

- 84/176 valid scored runs complete. Current tab map: tab5/fullTabs[0]=C18-A-01 (photo released); tab6/[1]=C17-a-B-01 (repeat released); tab7/[2]=C18-A-02 (photo released); tab8/[3]=C17-a-B-02 (initial). Remaining C17-b B runs have not started. Added endWaitingAt helper for valid terminal states awaiting user after scripted final event (C10 cases); no extra business action was invented. Added update_progress_report.py, stop_completed_drivers.py; driver cleanup only after final capture, never before C18/N11 late event. C04-b-B-01 score adjudicated per approved submitted-value gate: fail, F2/R4/S3=53; old review preserved in score-adjudications.jsonl. All genuine quality failures retained.

- 2026-11-20 recovery: 117/176 scored, 121 unique Sessions harvested. Browser RPC unavailable after tool migration; 4 runs pending UI review, 55 unstarted. No quality replacement runs or protocol changes. See 测评恢复点_2026-11-20.md.

- 2026-11-20 Browser connection restored. 122 primary scores now complete. Archived two C21 B starts under environment-incidents/browser-resume-render-server-offline-2026-11-20: localhost3001 actively refused connection after interruption. Restarted unchanged built json-render server, session35390. Total excluded starts now18. Repeating these only for setup/environment failure, not quality improvement. Active v2, renderer adapter/server/client, frozen inputs and initial materials match hashes; only disabled old v1 replay helper differs.

- Restored renderer on host after sandbox-bound listener failed host health requests. Active service exec session55969, startup 2026-11-20T05:44:52.768Z; /ping returned {ok:true}. No renderer or product code changes. Repeated C21 B inputs begin only after health confirmation.

- 2026-11-20 final: 176/176 primary runs scored and harvested, 176 unique Sessions, 44 initial-material groups equal across arms/repeats. All frozen initial prompts, DSH preset/model/tool schemas match; 187-file audit differs only in disabled old v1 replay.js. 18 excluded setup/environment starts retained. A pooled score90.82, B75.60; timing unscored. All completed replay pollers stopped after final evidence; viewport restored. Final reports and archive supersede earlier checkpoints.
