from pathlib import Path
import json,io,hashlib,zstandard
P=Path(r'C:/Users/CJY/.codex/visualizations/2026/11/18/01a1ede2-d2d9-7603-a35c-f4b22a5e8e4a/campus-benchmark/v0.5-formal')
SOURCE=Path(r'C:/Users/CJY/.dsh/sessions/--D-HuaweiMoveData-Users-CJY-Documents-deepseek-harness-default-workspace--')
summary=[]
for runfile in sorted((P/'runs').glob('*/run.json')):
 d=runfile.parent;r=json.loads(runfile.read_text('utf8'));bindfile=d/'binding.json'
 if not bindfile.exists():continue
 bind=json.loads(bindfile.read_text('utf8'));f=SOURCE/bind['session_id']/'session.v4.jsonl.zstd'
 if not f.exists():continue
 compressed=f.read_bytes()
 with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(compressed)) as stream:raw=stream.read()
 es=[json.loads(x) for x in raw.decode('utf8').splitlines()]
 (d/'session.jsonl.zstd').write_bytes(compressed);(d/'session.jsonl').write_bytes(raw)
 calls={};starts={};usage={};model_ms=0;render_ms=0;renders=[];texts=[];questions=[];users=[];events=[];presets=[];model=None;schema=None
 for e in es:
  v=e.get('data') or {};key=(v.get('turn'),v.get('step'))
  if e['type']=='agent-preset/selected':presets.append(v.get('agentPreset'))
  if e['type']=='step/start':starts[key]=e['time']
  if e['type']=='request/header':
   h=v.get('header') or {};cfg=h.get('config') or {};model={k:x for k,x in cfg.items() if k in ['provider','model','reasoningEffort']};schema=h.get('tools')
  if e['type']=='assistant/message':
   if key in starts:model_ms+=max(0,e['time']-starts[key])
   for k,x in (v.get('usage') or {}).items():
    if isinstance(x,(int,float)):usage[k]=usage.get(k,0)+x
   text='\n'.join(x.get('text','') for x in (v.get('message') or {}).get('content',[]) if x.get('type')=='text')
   if text:texts.append(dict(seq=e['seq'],turn=v.get('turn'),text=text))
  if e['type']=='tool/call':calls[v['callId']]=dict(event=e,time=e['time'],name=v['name'])
  if e['type']=='tool/result':
   msg=v.get('message') or {};cid=msg.get('toolCallId') or (msg.get('source') or {}).get('callId');c=calls.get(cid)
   if c:
    pair=dict(call_seq=c['event']['seq'],result_seq=e['seq'],call=c['event']['data'],meta=v.get('meta'),message=msg)
    if c['name']=='render_ui':render_ms+=max(0,e['time']-c['time']);renders.append(pair)
    if c['name']=='ask_user_question':questions.append(pair)
  if e['type']=='user/message':
   item=dict(seq=e['seq'],time=e['time'],source=v.get('source'),text='\n'.join(x.get('text','') for x in v.get('content',[]) if x.get('type')=='text'))
   (users if (v.get('source') or {}).get('kind')=='user' else events).append(item)
 metrics=dict(run_id=r['run_id'],session_id=bind['session_id'],status=r.get('status'),selected_preset=presets[-1] if presets else None,model=model,turns_started=sum(e['type']=='turn/start' for e in es),turns_ended=sum(e['type']=='turn/end' for e in es),model_ms=model_ms,render_ms=render_ms,active_ms=model_ms+render_ms,usage=usage,render_server_usage='not_observed',tool_calls=[c['name'] for c in calls.values()],render_calls=len(renders),question_calls=len(questions),tools_schema_sha256=hashlib.sha256(json.dumps(schema,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),environment_messages=len(events))
 for name,value in [('metrics',metrics),('render-results',renders),('question-results',questions),('assistant-outputs',texts),('user-inputs',users),('environment-inputs',events),('source-session',dict(session_id=bind['session_id'],source=str(f),sha256=hashlib.sha256(raw).hexdigest()))]:(d/(name+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 metrics['input_matches_frozen']=bool(users and users[0]['text']==(d/'input.txt').read_text('utf8').removesuffix('\n'))
 (d/'metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 summary.append(metrics)
(P/'metrics-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(collected=len(summary),completed=sum(m['status'] in ['pass','fail','partial'] for m in summary),running=[m['run_id'] for m in summary if m['status']=='running']),ensure_ascii=False))

